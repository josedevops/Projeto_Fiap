package br.entrega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntregaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntregaServiceApplication.class, args);
	}

}
